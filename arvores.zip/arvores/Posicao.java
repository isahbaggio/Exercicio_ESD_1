public interface Posicao<E> {
    E getElemento();
}
